#!/system/bin/sh
# Execute this script to removes the module
rm -rf /data/adb/modules/auto_target
#rm -rf /data/adb/modules/auto_target/cache
