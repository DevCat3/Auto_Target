#!/system/bin/sh
TARGET_FILE="/data/adb/tricky_store/target.txt"
echo "" > "$TARGET_FILE"
